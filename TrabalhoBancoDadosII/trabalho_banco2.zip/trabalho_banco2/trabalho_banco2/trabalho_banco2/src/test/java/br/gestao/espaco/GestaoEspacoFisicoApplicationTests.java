package br.gestao.espaco;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoEspacoFisicoApplicationTests {

}
