package br.gestao.espaco.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.gestao.espaco.configuration.LogAuditoria;
import br.gestao.espaco.exceptions.DuplicateException;
import br.gestao.espaco.exceptions.NotFoundException;
import br.gestao.espaco.mapper.AuditoriaMapper;
import br.gestao.espaco.model.Auditoria;
import br.gestao.espaco.repository.AuditoriaRepository;
import br.gestao.espaco.repository.UsuarioRepository;
import br.gestao.espaco.request.dto.AuditoriaRequest;
import br.gestao.espaco.request.dto.AuditoriaResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuditoriaService {

	private final UsuarioRepository usuarioRepository;
	private final AuditoriaRepository auditoriaRepository;
	private final AuditoriaMapper mapper;

	public List<AuditoriaResponse> findAll() {
		log.info("Buscando todas as auditorias...");
		List<Auditoria> auditorias = auditoriaRepository.findAll();
		if (auditorias.isEmpty()) {
			throw new NotFoundException("Nenhuma auditoria encontrada.");
		}
		return auditorias.stream()
				.map(mapper::fromAuditoria)
				.collect(Collectors.toList());
	}

	public AuditoriaResponse findById(Long auditoriaId) {
		log.info("Buscando auditoria com ID: {}", auditoriaId);
		return auditoriaRepository.findById(auditoriaId)
				.map(mapper::fromAuditoria)
				.orElseThrow(() -> new NotFoundException(
						String.format("Auditoria com ID %s não encontrada.", auditoriaId)));
	}

	@Transactional
	public Long createAuditoria(AuditoriaRequest request) {
		log.info("Criando nova auditoria para o usuário com ID: {}", request.UsuarioId());
		var usuario = usuarioRepository.findById(request.UsuarioId())
				.orElseThrow(() -> new NotFoundException(
						String.format("Usuário com ID %s não encontrado.", request.UsuarioId())));

		LocalDateTime windowStart = request.Data().minusSeconds(10);
		LocalDateTime windowEnd = request.Data().plusSeconds(10);

		boolean auditoriaExistente = auditoriaRepository.existsByUsuarioAndAcaoAndDataBetween(
				usuario, request.Acao(), windowStart, windowEnd);
		if (auditoriaExistente) {
			throw new DuplicateException(
					"Evento de auditoria similar foi detectado em um curto intervalo de tempo.");
		}

		Auditoria auditoria = mapper.toAuditoria(request);
		auditoria.setUsuario(usuario); // Associando o usuário ao objeto auditoria.
		auditoriaRepository.save(auditoria);

		log.info("Auditoria criada com sucesso. ID: {}", auditoria.getId());
		return auditoria.getId();
	}

	@Transactional
	public void updateAuditoria(Long auditoriaId, AuditoriaRequest request) {
		log.info("Atualizando auditoria com ID: {}", auditoriaId);
		var auditoria = auditoriaRepository.findById(auditoriaId)
				.orElseThrow(() -> new NotFoundException(
						String.format("Auditoria com ID %s não encontrada.", auditoriaId)));

		mergeAuditoria(auditoria, request);
		auditoriaRepository.save(auditoria);

		log.info("Auditoria com ID {} atualizada com sucesso.", auditoriaId);
	}

	@LogAuditoria(acao = "DELETE_AUDITORIA")
	@Transactional
	public void deleteAuditoria(Long auditoriaId) {
		log.info("Deletando auditoria com ID: {}", auditoriaId);
		if (!auditoriaRepository.existsById(auditoriaId)) {
			throw new NotFoundException(String.format("Auditoria com ID %s não encontrada.", auditoriaId));
		}
		auditoriaRepository.deleteById(auditoriaId);
		log.info("Auditoria com ID {} deletada com sucesso.", auditoriaId);
	}

	private void mergeAuditoria(Auditoria auditoria, AuditoriaRequest request) {
		log.debug("Mesclando dados da auditoria com ID: {}", auditoria.getId());
		auditoria.setAcao(request.Acao());
		auditoria.setData(request.Data());
		auditoria.setDetalhes(request.Detalhes());
	}
}
