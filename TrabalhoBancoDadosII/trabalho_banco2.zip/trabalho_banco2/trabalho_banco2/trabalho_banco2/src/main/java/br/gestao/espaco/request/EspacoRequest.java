package br.gestao.espaco.request;

import java.util.Set;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record EspacoRequest(
		
		@NotBlank(message = "ERRO! Nome do espaco não pode ficar vazio")
		@NotNull(message = "ERRO! Nome do espaco não pode ficar nulo")
		String Nome, 
		
		@NotBlank(message = "ERRO! Tipo não pode ficar vazio")
		@NotNull(message = "ERRO! Tipo não pode ficar nulo")
		String Tipo, 
		
		@Min(value = 3, message = "ERRO! Minimo é 3 metros")
		@Max(value = 100, message = "ERRO! Minimo é 3 metros")
		double Metragem, 
		
		Set<String> Equipamento) {

}
