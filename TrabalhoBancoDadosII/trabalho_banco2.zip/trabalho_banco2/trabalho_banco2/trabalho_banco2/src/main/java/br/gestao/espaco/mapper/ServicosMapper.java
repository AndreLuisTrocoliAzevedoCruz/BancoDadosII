package br.gestao.espaco.mapper;

import org.springframework.stereotype.Service;

import br.gestao.espaco.model.Avaliador;
import br.gestao.espaco.model.Equipamento;
import br.gestao.espaco.model.Feriado;
import br.gestao.espaco.request.AvaliadorResponse;
import br.gestao.espaco.request.EquipamentoRequest;
import br.gestao.espaco.request.EquipamentoResponse;
import br.gestao.espaco.request.HolidayRequest;
import br.gestao.espaco.request.HolidayResponse;

@Service
public class ServicosMapper {

	public Feriado toFeriado(HolidayRequest request) {
		if (request == null) {
			return null;
		}

		return Feriado.builder().nome(request.Nome()).data(request.Data()).build();
	}

	public HolidayResponse fromFeriado(Feriado feriado) {
		return new HolidayResponse(feriado.getId(), feriado.getNome(), feriado.getData());
	}

	public Equipamento toEquipamento(EquipamentoRequest request) {
		if (request == null) {
			return null;
		}

		return Equipamento.builder().nome(request.Nome()).build();
	}

	public EquipamentoResponse fromEquipamento(Equipamento equipamento) {
		return new EquipamentoResponse(equipamento.getId(), equipamento.getNome());
	}
	
	public AvaliadorResponse fromAvaliador(Avaliador avaliador) {
		return new AvaliadorResponse(avaliador.getId(), avaliador.getAvaliador());
	}

}
