package br.gestao.espaco.request.dto;

import br.gestao.espaco.model.Disponibilidade;

public record DisponibilidadeDTO(Long Id, String Nome, String Tipo, Disponibilidade Disponibilidade) {

}
