package br.gestao.espaco.exceptions;

import lombok.Data;
import lombok.EqualsAndHashCode;

@SuppressWarnings("serial")
@EqualsAndHashCode(callSuper = true)
@Data
public class InvalidFormatDate extends CustomGlobalException {

	private final String msg;
	
}
