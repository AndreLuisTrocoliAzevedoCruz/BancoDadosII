package br.gestao.espaco.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record EquipamentoRequest(
		
		@NotBlank(message = "ERRO! Nome do equipamento não pode ficar vazio")
		@NotNull(message = "ERRO! Nome do equipamento não pode ficar nulo")
		String Nome) {

}
