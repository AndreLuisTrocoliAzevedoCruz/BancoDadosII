package br.gestao.espaco.exceptions;

import java.util.Map;

public record ErrorResponse(Map<String, String> errors) {
}
