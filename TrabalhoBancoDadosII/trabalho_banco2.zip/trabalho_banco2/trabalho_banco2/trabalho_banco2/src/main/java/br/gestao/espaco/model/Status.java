package br.gestao.espaco.model;

public enum Status {

	PENDENTE, APROVADA, REJEITADA;

}
