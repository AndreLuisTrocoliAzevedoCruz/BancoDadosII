package br.gestao.espaco.request;

public record EquipamentoResponse(Long Id, String Nome) {

}
