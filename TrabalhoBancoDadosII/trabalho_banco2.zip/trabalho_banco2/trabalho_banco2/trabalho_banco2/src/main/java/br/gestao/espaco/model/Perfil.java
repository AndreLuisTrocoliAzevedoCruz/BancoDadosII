package br.gestao.espaco.model;

public enum Perfil {

	PROFESSOR, GESTOR, ADMINISTRADOR
	
}
