package br.gestao.espaco.request.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record AuditoriaRequest(
		
		Long UsuarioId,
		
		@NotBlank(message = "ERRO! Acao é obrigatório")
		String Acao,
		
		@NotNull(message = "ERRO! Data é obrigatório")
        LocalDateTime Data,

		@NotBlank(message = "ERRO! Detalhes é obrigatório")
		String Detalhes
		
		) {

}
