package br.gestao.espaco.request;

import java.time.LocalDate;

public record HolidayResponse(Long Id, String Nome, LocalDate Data) {

}
