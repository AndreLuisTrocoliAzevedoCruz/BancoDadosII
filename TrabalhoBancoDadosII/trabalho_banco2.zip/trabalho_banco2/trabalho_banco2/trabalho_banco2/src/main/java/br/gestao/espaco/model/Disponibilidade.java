package br.gestao.espaco.model;

public enum Disponibilidade {

	DISPONIVEL, INDISPONIVEL
	
}
