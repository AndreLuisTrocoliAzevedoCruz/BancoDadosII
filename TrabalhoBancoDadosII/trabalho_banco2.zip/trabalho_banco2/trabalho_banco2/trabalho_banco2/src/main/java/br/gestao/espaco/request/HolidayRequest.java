package br.gestao.espaco.request;

import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record HolidayRequest(
		
		@NotNull(message = "ERRO! Nome do feriado não pode ficar nulo")
		@NotBlank(message = "ERRO! Nome do feriado não pode ficar vazio")
		String Nome,
		
		@NotNull(message = "ERRO! Data não pode ficar nula")
		LocalDate Data) {

}
