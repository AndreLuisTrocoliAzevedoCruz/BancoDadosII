INSERT INTO Usuarios (nome, email)
VALUES
    ('Lucas Pereira', 'lucas.pereira@example.com'),
    ('Mariana Gomes', 'mariana.gomes@example.com'),
    ('Rafael Lima', 'rafael.lima@example.com');

INSERT INTO Perfis (id_usuario, perfil)
VALUES
    (1, 'ALUNO'),
    (1, 'PROFESSOR'),
    (2, 'GESTOR');


INSERT INTO Feriados (nome, data)
VALUES
    ('Dia da Independência', '2024-09-07'),
    ('Dia de Finados', '2024-11-02'),
    ('Natal', '2024-12-25');

INSERT INTO Equipamentos (nome)
VALUES
    ('Cadeira Ergonômica'),
    ('Impressora a Laser'),
    ('Projetor Laser');

INSERT INTO Espacos_fisicos (nome, tipo, metragem, disponibilidade)
VALUES
    ('Sala de Conferências', 'Sala', 35.00, 'DISPONIVEL'),
    ('Área Externa para Eventos', 'Espaço Externo', 300.00, 'DISPONIVEL'),
    ('Laboratório de Informática', 'Laboratório', 50.00, 'DISPONIVEL');

INSERT INTO Espacos_Equipamentos (id, equipamento_id)
VALUES
    (1, 3),
    (2, 2),
    (3, 1)
